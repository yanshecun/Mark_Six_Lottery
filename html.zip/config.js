//头数玩法
apiwf(jsonData,'toushu_div_tetou','hm_sx',3,200,0,'-',10,0,kmc);

//日夜肖
apiwf(jsonData,'riyexiao','hm_ryx',1,130,0,'|',10,0,kmc);

//风雨雷电
apiwf(jsonData,'fengyuleidian','hm_fyld',3,150,0,'|',10,0,kmc);

//文武肖
apiwf(jsonData,'wenwuxiao','hm_wwx',1,170,0,'|',10,0,kmc);

//三国肖
apiwf(jsonData,'sanguoxiao','hm_sgx',2,190,0,'|',10,0,kmc);

//左右肖
apiwf(jsonData,'zuoyouxiao','hm_zyx',1,123,0,'|',10,0,kmc);

//黑白肖
apiwf(jsonData,'heibaixiao','hm_hbx',1,145,0,'|',10,0,kmc);

//草肉菜肖
apiwf(jsonData,'roucaocai','hm_rcc',2,157,0,'|',10,0,kmc);

//尾数玩法
apiwf(jsonData,'weishu_div_tewei','hm_sx',5,300,0,'-',10,0,kmc);

//真言玩法
apiwf(jsonData,'zhenyan_ping_xiao','hm_sx',1,190,0,'+',10,0,kmc);
//名词玩法
apiwf(jsonData,'mingci_ping_xiao','hm_sx',3,190,0,'+',10,0,kmc);
//成语玩法
apiwf(jsonData,'chengyu_ping_xiao','hm_sx',1,190,0,'+',10,0,kmc);
//平肖玩法
apiwf(jsonData,'shengxiao_ping_xiao','hm_sx',3,190,0,'+',10,0,kmc);
//平尾玩法
apiwf(jsonData,'weishu_ping_wei','hm_sx',1,1,0,'-',10,0,kmc);
//金字塔玩法
apiwf(jsonData,'jinzita_jinzita','每期都是用心做！欢迎你的到来',9,200,0," ",2,0,kmc);
//肖码玩法
apiwf(jsonData,'xiaoma_xiaoma','hm_dmx',6,10,0,'|',10,0,kmc);


//代码肖
apiwf(jsonData,'daimingxiao','hm_dmx',5,100,0,'|',10,0,kmc);
//六合肖
apiwf(jsonData,'liuhexiao','hm_lhx',4,160,0,'+',10,0,kmc);
//三合肖
apiwf(jsonData,'sanhexiao','hm_shx',3,160,0,'+',10,0,kmc);
//方位肖 
apiwf(jsonData,'fangweixiao','hm_fwx',3,160,0,'+',10,0,kmc);
//四季肖
apiwf(jsonData,'sijixiao','hm_sjx',3,160,0,'+',10,0,kmc);
//三色肖
apiwf(jsonData,'sansexiao','hm_ssx',2,160,0,'+',10,0,kmc);
//阴阳肖
apiwf(jsonData,'yinyang','hm_yyx',1,160,0,'+',10,0,kmc);
//美丑肖
apiwf(jsonData,'meichou','hm_mcx',1,160,0,'+',10,0,kmc);
//笔画肖
apiwf(jsonData,'bihua','hm_bhx',1,160,0,'+',10,0,kmc);
//男女肖
apiwf(jsonData,'nannv','hm_nnx',1,160,0,'+',10,0,kmc);
//琴棋书画
apiwf(jsonData,'qinqishuhua','hm_qqsh',3,120,0,'+',10,0,kmc);
//天地肖
apiwf(jsonData,'tiandi','hm_tdx',1,110,0,'+',10,0,kmc);
//前后肖
apiwf(jsonData,'qianhou','hm_qhx',1,130,0,'+',10,0,kmc);
//家野肖
apiwf(jsonData,'jiaye','hm_jyx',1,140,0,'+',10,0,kmc);
//单双肖
apiwf(jsonData,'danshuang','hm_ds',1,190,0,'+',10,0,kmc);
//大小肖
apiwf(jsonData,'daxiao','hm_dx',1,30,0,'+',10,0,kmc);
//波色肖
apiwf(jsonData,'bose','hm_bs',2,100,0,'+',10,0,kmc);
//五行肖
apiwf(jsonData,'wuxing','hm_wx',3,100,0,'+',10,0,kmc);
//多肖
apiwf(jsonData,'shengxiao','hm_sx',8,100,0,'+',10,0,kmc);
//多码
apiwf(jsonData,'haoma','hm_sz',24,100,0,'+',10,0,kmc);

//十三合
apiwf(jsonData,'shisanhe_shu',"hm_ssh",7,130,0,"-",10,0,kmc);  
//特码头
apiwf(jsonData,'tou_shu',"hm_ttx",3,130,0,".",10,0,kmc); 
//特码尾
apiwf(jsonData,'wei_shu',"hm_twx",6,130,0,",",10,0,kmc); 

//五门肖
apiwf(jsonData,'wumen_shu',"hm_wmx",3,130,0,",",10,0,kmc);   
//七段肖
apiwf(jsonData,'qiduan_shu',"hm_qdx",5,130,0,",",10,0,kmc); 
//合大小
apiwf(jsonData,'hedaxiao_shu',"hm_hdx",1,130,0,",",10,0,kmc); 


//尾大小
apiwf(jsonData,'weidaxiao_shu',"hm_wdx",1,130,0,",",10,0,kmc); 
//合单双
apiwf(jsonData,'hedanshuang_shu',"hm_hds",1,130,0,",",10,0,kmc); 
//合尾肖
apiwf(jsonData,'hewei_shu',"hm_hw",4,130,0,",",10,0,kmc); 
//半波大小
apiwf(jsonData,'banbodaxiao_shu',"hm_bbdx",4,130,0,",",10,0,kmc); 
//半波单双
apiwf(jsonData,'banbodanshuang_shu',"hm_bbds",4,130,0,",",10,0,kmc);  
//单双大小
apiwf(jsonData,'danshuangdaxiao_shu',"hm_dsdx",3,130,0,",",10,0,kmc); 
//头单双
apiwf(jsonData,'toudanshuang_shu',"hm_tds",5,130,0,",",10,0,kmc); 